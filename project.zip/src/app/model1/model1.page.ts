import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-model1',
  templateUrl: './model1.page.html',
  styleUrls: ['./model1.page.scss'],
})
export class Model1Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
